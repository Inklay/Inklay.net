# ETS2Sync-Helper-Server

A Node.JS server hosting the jobs lists for [ETS2Sync-Helper](https://github.com/Inklay/ETS2Sync-Helper)
